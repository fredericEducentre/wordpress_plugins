<?php
/**
 * Plugin Name: Get zodiac sign
 * Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
 * Description: A brief description of the Plugin.
 * Version: The Plugin's Version Number, e.g.: 1.0
 * Author: Name Of The Plugin Author
 * Author URI: http://URI_Of_The_Plugin_Author
 * License: A "Slug" license name e.g. GPL2
 */
 
/*  Copyright YEAR  PLUGIN_AUTHOR_NAME  (email : PLUGIN AUTHOR EMAIL)
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

function get_chinese_zodiac($year) {
    $zodiac = array(
        'Rat', 'Ox', 'Tiger', 'Rabbit', 'Dragon', 'Snake', 
        'Horse', 'Goat', 'Monkey', 'Rooster', 'Dog', 'Pig'
    );
    return $zodiac[($year - 4) % 12];
}

function zodiac_form() {
    ob_start();
    ?>
    <form method="post" action="">
        <label for="year">Enter Year:</label>
        <input type="number" id="year" name="year" required>
        <input type="submit" name="submit" value="Get Zodiac Sign">
    </form>
    <?php
    if (isset($_POST['submit'])) {
        $year = sanitize_text_field($_POST['year']);
        if (is_numeric($year)) {
            $zodiac_sign = get_chinese_zodiac($year);
            echo '<p>The Chinese Zodiac sign for the year ' . $year . ' is ' . $zodiac_sign . '.</p>';
        } else {
            echo '<p>Please enter a valid year.</p>';
        }
    }
    return ob_get_clean();
}

add_shortcode('chinese_zodiac', 'zodiac_form');